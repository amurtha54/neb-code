from mep.optimize import ScipyOptimizer
from mep.optimize import SGD
from mep.path import Path
from mep.neb import NEB
from mep.models import LEPS
from mep.models import LEPSHarm
from mep.models import Test

# ____ Using SGD Optimizer ____ #
def OG_SGD():
    leps = LEPS() # Test model
    op = SGD(leps) # local optimizer for finding local minima
    x0 = op.step(1) # minima one
    x1 = op.step(3) # minima two

    path = Path.from_linear_end_points(x0, x1, 101, 1)  # set 101 images, and k=1
    neb = NEB(leps, path) # initialize NEB
    history = neb.run(verbose=True) # run

# ____ Original Case ___ #
def OG():
    leps = LEPS() # Test model
    op = ScipyOptimizer(leps) # local optimizer for finding local minima
    x0 = op.minimize([1, 4], bounds=[[0, 4], [-2, 4]]).x # minima one
    x1 = op.minimize([4, 1], bounds=[[0, 4], [-2, 4]]).x # minima two

    path = Path.from_linear_end_points(x0, x1, 101, 1)  # set 101 images, and k=1
    neb = NEB(leps, path) # initialize NEB
    history = neb.run(verbose=True) # run

# ___ Test Case ___ #
def Mine():
    test = Test() # Test model
    x0 = [0, 3]  # parabola conditions: [0, 0] / saddle conditions: [0, 3]
    x1 = [4, 3]  # parabola conditions: [4, 0] / saddle conditions: [4, 3]
    print('Min 1:', x0)
    print('Min 2:', x1)

    path = Path.from_linear_end_points(x0, x1, 101, 1)  # set 101 images, and k=1
    neb = NEB(test, path) # initialize NEB
    history = neb.run(verbose=True) # run

Mine()